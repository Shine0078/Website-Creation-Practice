<?php
   define("DB_HOST", "localhost");
   define("DATABASE", "abc_db");
   define("DB_ADMIN", "abc");
   define("DB_PORT", "5433");
   define("DB_PASSWORD", "abc");

   define("ADMIN",'a');
   define('SALES','s');

   define("RECORDS " , 5);
?>