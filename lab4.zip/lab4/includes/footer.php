  <!--Name: Samuel Abraham
 * Date: December 09, 2023
 * Description: The footer part where it is attached to the ending of the web page.

-->          
                </div>
            <footer>
                <p class="mt-5 mb-3 text-muted text-center">&copy; 2020</p>
                <p ><a class="text-info"  href="./AUP.php"> Acceptable Use Policy</a>  </p>
                <p><a class="text-info" href="./cookie.php">Cookie Policy</a> </p>
                <p><a class="text-info" href="./PrivacyPolicy.php">Privacy Policy</a> </p>
            </footer>
        </main>  
       </div>
    </div>
  </body>
</html>