<!--Name: Samuel Abraham
 * Date: December 09, 2023
 * Description: This file contains the constants that is used for the website creation and for this lab.
-->
<?php
$file = "Lab4.php";
$date = " December 09 ,2023";
$title = "Lab4";
$desc = "This file contains the nessecary constatnts for the website creation & Lab 4.";
$banner = "Web Development Course - Lab 4";




//THE below Is the constant for the Datbase 
// To conNECT TO THE sql Database
define("DB_HOST", "localhost");
define("DATABASE", "samuel_db");
define("DB_ADMIN", "abraham_db");
define("DB_PORT", "5433");
define("DB_PASSWORD", "Shine1081@");



define("RECORDS " , 5);

   
?>